for i in `seq 32 126`;
        do
                ./alphatize.sh $i
        done   
